# Pulse Key | Oura Ring 4 wearer-authentication research

**Current status: 3 November 2026.** This README supersedes dated project summaries before this date.

**Target:** Enroll person X on one old Oura Ring 4 and accept X / reject unfamiliar wearers of that same physical ring across independent days and reseats. **Status:** identity unvalidated; live Mac demo only provides possession/custody, intent, and a liveness indication. No scientifically defensible FAR or FRR. No production identity gate.

## Where to begin

1. `Research/2026-11-03_MASTER_EVIDENCE_AND_STATUS.md`: authoritative evidence and present scientific limits.
2. `Research/2026-11-03_SUPERSESSION_AND_ERRATA.md`: corrections to 2026-10-30 through 2026-11-02 work.
3. `Research/2026-11-03_MEASUREMENT_CORRECTION.md`: decoder defect, corrected data and independently reproduced results.
4. `Research/2026-11-03_ASTRA_INDEPENDENT_REPORT_SOURCE.md`: complete user-supplied independent Astra report, with provenance caveat.
5. `Research/2026-11-03_NEXT_EXPERIMENT_PROTOCOL.md`: exact execution plan, decision gates and privacy controls.
6. `Research/Pulse_Key_Phase1_Corrected_Offline_v2_2026-11-03.zip`: **corrected offline research package; not a Mac daemon patch**.
7. `Research/2026-11-03_OFFLINE_REPRODUCTION_AGGREGATES.json`: actual locally rerun verification outputs, no raw waveforms or private keys.

## Most important corrections

- v1 Library waveform decoder **double-integrated** packet-relative offsets. v1 owner-vs-Y waveform scores, template and threshold `0.793096` were computed on distorted data and are superseded.
- Corrected v2 owner-trained threshold: **0.517940**. Later clean X distance **0.170049**; Y distances **0.188865** and **0.196780**. Both Y waveforms still score as pass. Historical optical difference X nine observations `−3..0`, Y six `+1..+3`, caused the two clean Y rejections. **This remains a two-person post-hoc finding.**
- Binary calibration multiset correspondence now verified **15/15 bursts** with both tuples/slot variants (the old limited parser missed two). This does not verify anatomical path meaning or exact chronological writes.
- The older public comparison **82/139** against the bad v1 owner template is obsolete as evidence about corrected v2. The separate *within-public* cross-day weak AUC remains relevant to that public dataset.
- Old feasibility and stranger-collision percentages were guesses. Ignore them. The reported 18 optical paths do not imply available concurrent 18-channel raw recordings.

## Next action

**Gate 0:** Have the local Mac agent inspect the newly corrected offline v2 package and independently verify decoder/regression fixes, keeping the existing Mac optical-only baseline frozen and the live Rust daemon unchanged.

**Gate 1:** Collect **five new X ordinary remove/reseat recordings today and five another day**, logging every attempted capture and quality failure. If owner stability is adequate, **Gate 2:** five consenting unfamiliar people, three fresh reseats per person across two days, randomized/interleaved with owner returns. Freeze rules before either cohort.

No stored `oura.db`, pairing key, raw biometric streams, or owner biometric templates are included in this Library release. Prior dated ZIPs/reports remain historical evidence; see errata before quoting them.
