# Pulse Key handoff: start here (3 November 2026)

**Independent verdict:** Engineering progress is real; wearer-specific identity has no demonstrated reliability. The latest substantial discovery was a waveform-decoding bug in v1 Library code. Current corrected v2 offline tests pass 20/20 with private historical DB; this is a measurement repair, not security validation.

Open `Research/2026-11-03_MASTER_EVIDENCE_AND_STATUS.md`, `Research/2026-11-03_SUPERSESSION_AND_ERRATA.md`, `Research/2026-11-03_MEASUREMENT_CORRECTION.md` and the complete `Research/2026-11-03_ASTRA_INDEPENDENT_REPORT_SOURCE.md`. Inspect historical ZIPs only with the correction manifest.

Immediate engineering instruction: take the v2 offline source to the local Mac repo, compare reconstruction with Rust raw-frame decoder and independent Astra artifacts, add packet-boundary regressions, freeze source/profile/version hashes. Keep the old optical-only prospective `[-5,0]` baseline **unaltered**. No live Mac daemon changes; no upload of owner template, raw database or ring BLE keys.

First physical test after Gate 0: 5 ordinary fresh X reseats, second day 5 further X reseats, record all attempted/eligible ACCEPT, REJECT and INCONCLUSIVE. Then 5 unfamiliar consenting people across 2 days with 3 reseats each, contingent on usable owner acceptance. Explicitly separate physiological identity from custody/tap/knowledge-of-secret. Full protocol: `Research/2026-11-03_NEXT_EXPERIMENT_PROTOCOL.md`.
